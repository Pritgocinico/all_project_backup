<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Hash;
use Session;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\Customer;
use App\Models\Log;
use App\Models\Setting;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use App\Models\AccessToken;

class CustomerApiController extends Controller
{
    public function __construct() {
        $setting=Setting::first();
        view()->share('setting', $setting);
    }
    public function Customers(Request $request){
        $customers = Customer::orderBy('id','Desc')->get();
        $array_push = array();
        if(!blank($customers)){
            foreach($customers as $customer){
                $array = array();
                $array['id']            = $customer->id;
                $array['name']          = ($customer->name != NULL)?$customer->name:"";
                $array['email']         = ($customer->email != NULL)?$customer->email:"";
                $array['phone']         = ($customer->phone != NULL)?$customer->phone:"";
                $array['status']        = ($customer->status != NULL)?(int)$customer->status:0;
                $array['created_at']    = ($customer->created_at != NULL)?$customer->created_at:"";
                array_push($array_push,$array);
            }
            return response()->json([
                'status' => 1,
                'customers'=>$array_push
            ],200);
        }else{
             return response()->json(['status'=>0,'error'=> 'Customers Not Found.'],404);
        }
    }
    public function storeCustomer(Request $request){
        $validator = Validator::make($request->all(), [
            'name'                => 'required|unique:customers,name',
        ]);
        if ($validator->fails()) {
            return response()->json(['status'=>0,'error'=>implode(" ", $validator->errors()->all())], 404);
        }else{
            $customer = new Customer();
            $customer->name         = $request->name;
            $customer->email        = $request->email;
            $customer->phone        = $request->phone;
            $customer->status       = 1;
            $customer->save();

            if($customer){
                $user = User::where('id',$request->user_id)->first();
                $log = new Log();
                $log->user_id   = $user->name;
                $log->module    = 'Customers';
                $log->log       = 'Customers ('.$request->name.') Created.';
                $log->save();
                return response()->json(['status'=>1,'message'=>'Customers added successfully.'],200);
            }else{
                return response()->json(['status'=>0,'error'=>'Something went wrong.'],404);
            }
        }
    }
    public function deleteCustomer(Request $request, $id){
        if(!blank($id)){
            $customer = Customer::where('id',$id)->first();
            if(!blank($customer)){
                $user = User::first();
                $log = new Log();
                $log->user_id   = $user->name;
                $log->module    = 'Customers';
                $log->log       = 'Customer ('.$customer->name.') Deleted.';
                $log->save();
                $customer->delete();
            }else{
                return response()->json(['status'=>0,'error'=>'Something Went Wrong.'],200);
            }
            return response()->json(['status'=>1,'message'=>'Customer deleted successfully!'],200);
        }else{
           return response()->json(['status'=>0,'error'=>'Something Went Wrong.'],200);
        }
    }
    public function updateCustomer(Request $request){
        $validator = Validator::make($request->all(), [
            'name'                => 'required|unique:customers,name,'.$request->company_id,
        ]);
        if ($validator->fails()) {
            return response()->json(['status'=>0,'error'=>implode(" ", $validator->errors()->all())], 404);
        }else{
            $customer = Customer::where('id',$request->customer_id)->first();
            if(!blank($customer)){
                $customer->name         = $request->name;
                $customer->email        = $request->email;
                $customer->phone        = $request->phone;
                $customer->status       = $request->status;
                $customer->save();

                if($customer){
                    $user = User::where('id',$request->user_id)->first();
                    $log = new Log();
                    $log->user_id   = $user->name;
                    $log->module    = 'Customers';
                    $log->log       = 'Customer ('.$request->name.') Updated.';
                    $log->save();
                    return response()->json(['status'=>1,'message'=>'Customer updated successfully.'],200);
                }else{
                    return response()->json(['status'=>0,'error'=>'Something went wrong.'],404);
                }
            }else{
                return response()->json(['status'=>0,'error'=>'Something went wrong.'],404);
            }
        }
    }
}
