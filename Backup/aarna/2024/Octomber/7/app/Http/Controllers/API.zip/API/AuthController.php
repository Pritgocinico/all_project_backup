<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Hash;
use Session;
use App\Models\RoleUser;
use App\Models\User;
use App\Models\Category;
use App\Models\Log;
use App\Models\Setting;
use App\Models\Company;
use App\Models\SourcingAgent;
use App\Models\SourcingAgentPayout;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use App\Models\AccessToken;

class AuthController extends Controller
{
    public function __construct() {
        $setting=Setting::first();
        view()->share('setting', $setting);
    }
    
    // User Login
    public function loginUser(Request $req){
        $input = $req->all();
        $validator = Validator::make($req->all(), [
           'email'               => 'required',
           'password'            => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json(['status'=>0,'error_type'=>4,'error'=>$validator->errors()], 404);
        }else{
            $fieldType = filter_var($req->email, FILTER_VALIDATE_EMAIL) ? 'email' : 'phone';
            $credentials = $req->only($fieldType, 'password');
            if (Auth::attempt(array($fieldType => $input['email'], 'password' => $input['password']))) {
               $role = Auth::user()->role;
               $user=Auth::user();
                if($user->role == 1){
                    if($user->status == 1){
                        $user->update([
                            'last_login_at' => Carbon::now()->toDateTimeString(),
                            'last_login_ip' => $req->getClientIp()
                        ]);
                        $log = new Log();
                        $log->user_id   = $user->name;
                        $log->module    = 'Login';
                        $log->log       = $user->name.' Logged in Successfully';
                        $log->save();
                        
                        if(!blank($user)){
                            $array = array();
                            $array['id'] = $user->id;
                            if(!blank($user->image)){
                                $array['image'] = url('/').'/public/users/'.$user->image;
                            }else{
                                $array['image'] = '';
                            }
                            $array['name']          = $user->name;
                            $array['email']         = $user->email;
                            $array['phone']         = $user->phone;
                            $array['status']        = $user->status;
                            $accessToken = AccessToken::updateOrCreate(
                                [ 'user_id' => $user->id ],
                                [ 'access_token' => Str::random(255) ]
                            );
                            return response()->json(['status'=>1,'access_token' =>  $accessToken->access_token ,'user_details'=>$array],200);
                        }else{
                            return response()->json(['status'=>0,'error_type'=>1,'error'=>'User Not Found.'],404);
                        }
                    }else{
                        return response()->json(['status'=>0,'error_type'=>2,'error'=>'User Not Verified.'],404);
                    }
                }
            }else{
               return response()->json(['status'=>0,'error_type'=>3,'error'=>'Wrong Username or Password.'],200);
            }
        }
    }

    //Admin Dashboard
    public function Dashboard(Request $request){
        echo "Dashboard";
    }
}
